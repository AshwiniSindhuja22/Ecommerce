import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-product-dateslot-relation',
  templateUrl: './product-dateslot-relation.component.html',
  styleUrls: ['./product-dateslot-relation.component.css']
})
export class ProductDateslotRelationComponent implements OnInit{
  productdatelist:any;
  productlist:any;

  constructor(){
   
  }
  ngOnInit(): void {
    
  }

}
