export class Product {
    productId!:number;
    productName!:String;
    price!:number;
    category!:String;
    brand!:String;
    availableproduct!:number;

}
