import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
<<<<<<< HEAD
  title = 'Welcome To Ecommerce_Website';
=======
  title = 'Ecommerce_Website';
>>>>>>> 4eae404 (initial commit)
}
