import { AssignmentProductDateslot } from './assignment-product-dateslot';

describe('AssignmentProductDateslot', () => {
  it('should create an instance', () => {
    expect(new AssignmentProductDateslot()).toBeTruthy();
  });
});
