export class Customer {
    customerId!:number;
    customerName!:String;
    age!:number;
    gender!:String;
    email!:String;
    phno!:String;
    password!:String;
    address!:String;
}
