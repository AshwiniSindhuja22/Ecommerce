

export class DateSlot {
    id!:number;
    orderDate!:Date;
    deliveryDate!:Date;

}
