import { DateSlot } from './date-slot';

describe('DateSlot', () => {
  it('should create an instance', () => {
    expect(new DateSlot()).toBeTruthy();
  });
});
