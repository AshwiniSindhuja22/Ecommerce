export class AssignmentProductDateslot {
    productId!:number;
    dateslotId!:number;
}
