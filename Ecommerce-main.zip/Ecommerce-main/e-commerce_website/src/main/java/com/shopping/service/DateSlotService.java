package com.shopping.service;

import com.shopping.Entities.DateSlot;

public interface DateSlotService {
DateSlot createDateSlot(DateSlot dateSlot);
}
